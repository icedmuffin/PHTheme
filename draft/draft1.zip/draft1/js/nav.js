var item = document.getElementById('item');
function showmenu() {
    var submenu = document.getElementById('sub-menu');
    submenu.className = "show-sub";
}

